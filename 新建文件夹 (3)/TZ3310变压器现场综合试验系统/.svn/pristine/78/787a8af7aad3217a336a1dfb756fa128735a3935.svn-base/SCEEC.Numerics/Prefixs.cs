﻿using SCEEC.Numerics.Quantities;
using System;
using System.Collections.Generic;
using System.Text;

namespace SCEEC.Numerics
{
    public enum Prefixs
    {
        y = -24,
        z = -21,
        a = -18,
        f = -15,
        p = -12,
        n = -9,
        μ = -6,
        m = -3,
        None = 0,
        k = 3,
        M = 6,
        G = 9,
        T = 12,
        P = 15,
        E = 18,
        Z = 21,
        Y = 24
    }

    public struct PhysicalVariable
    {
        public double value;
        public QuantityName PhysicalVariableType;
    }

    public static class PrefixsConverter
    {
        public static string dec2prefixString(int dec)
        {
            if (dec >= 0)
            {
                dec = dec / 3;
                dec = dec * 3;
            }
            else
            {
                dec = (dec - 2) / 3;
                dec = dec * 3;
            }
            switch (dec)
            {
                case -24:
                    return "y";
                case -21:
                    return "z";
                case -18:
                    return "a";
                case -15:
                    return "f";
                case -12:
                    return "p";
                case -9:
                    return "n";
                case -6:
                    return "μ";
                case -3:
                    return "m";
                case 0:
                    return " ";
                case 3:
                    return "k";
                case 6:
                    return "M";
                case 9:
                    return "G";
                case 12:
                    return "T";
                case 15:
                    return "P";
                case 18:
                    return "E";
                case 21:
                    return "Z";
                case 24:
                    return "Y";
                default:
                    throw new Exception("值大小过大或过小。");
            }
        }

        public static int prefixString2dec(string prefix)
        {
            switch (prefix)
            {
                case "y": return -24;
                case "z": return -21;
                case "a": return -18;
                case "f": return -15;
                case "p": return -12;
                case "n": return -9;
                case "μ": return -6;
                case "m": return -3;
                case "": return 0;
                case " ": return 0;
                case "k": return 3;
                case "M": return 6;
                case "G": return 9;
                case "T": return 12;
                case "P": return 15;
                case "E": return 18;
                case "Z": return 21;
                case "Y": return 24;
                default:
                    throw new Exception("SI词头不正确。");
            }
        }

        public static bool isPrefix(string word)
        {
            if (word == string.Empty) return true;
            if (word.Length > 1) return false;
            return ("yzafpnμm kMGTPEZY".IndexOf(word) > -1);
        }
    }

    public static class NumericsConverter
    {
        /// <summary>
        /// 将数值转换自动转换为SI词头的有效位数表示方式
        /// </summary>
        /// <param name="value">需要转换的数值</param>
        /// <param name="effectiveLength">有效位数长度（必须是正整数）</param>
        /// <param name="noiseLevel">物理量底噪电平</param>
        /// <param name="prefix">数值预设词头</param>
        /// <param name="quantity">数值单位</param>
        /// <returns>SI词头的有效位数表示方式文本</returns>
        public static string Value2Text(double value, int effectiveLength, int noiseLevel, string prefix, string quantity)
        {
            string rtn = string.Empty;
            if (effectiveLength < 1) { return "#"; throw new Exception("有效位数需要为正整数。"); }
            if (Math.Abs(value) < 1e-24) { return ("0" + quantity); }
            if (value < 0) { value = -value; rtn = "-"; }
            value *= Math.Pow(10, PrefixsConverter.prefixString2dec(prefix));
            int decCnt = (int)Math.Floor(Math.Log10(value));
            prefix = PrefixsConverter.dec2prefixString(Math.Max(PrefixsConverter.prefixString2dec(PrefixsConverter.dec2prefixString(decCnt)), noiseLevel + effectiveLength - 1));
            if ((decCnt - effectiveLength + 1) < noiseLevel)
                effectiveLength = decCnt - noiseLevel + 1;
            if ((decCnt - PrefixsConverter.prefixString2dec(prefix)) >= effectiveLength)
                prefix = PrefixsConverter.dec2prefixString(PrefixsConverter.prefixString2dec(prefix) + 3);
            value /= Math.Pow(10, PrefixsConverter.prefixString2dec(prefix));
            decCnt = (int)Math.Floor(Math.Log10(value));
            value = Math.Round(value, effectiveLength - Math.Min(0, decCnt + 1), MidpointRounding.AwayFromZero);
            if (value < 1e-24) { return ("0" + quantity); }
            string format;
            if (value >= 1) format = "F" + Math.Max((effectiveLength - ((decCnt + 48) % 3) - 1), 0).ToString();
            else format = "F" + Math.Max((effectiveLength - decCnt - 1), 0).ToString();
            rtn += value.ToString(format);
            return (rtn + " " + prefix + quantity);
        }

        /// <summary>
        /// 将数值转换自动转换为SI词头的有效位数表示方式
        /// </summary>
        /// <param name="value">需要转换的数值</param>
        /// <param name="effectiveLength">有效位数长度（必须是正整数）</param>
        /// <param name="noiseLevel">物理量底噪电平</param>
        /// <param name="prefix">数值预设词头</param>
        /// <param name="quantity">物理量类型</param>
        /// <returns>SI词头的有效位数表示方式文本</returns>
        public static string Value2Text(double value, int effectiveLength, int noiseLevel, string prefix, QuantityName quantity)
        {
            switch (quantity)
            {
                case QuantityName.Capacitance:
                    return Value2Text(value, effectiveLength, noiseLevel, prefix, "F");
                case QuantityName.Charge:
                    return Value2Text(value, effectiveLength, noiseLevel, prefix, "C");
                case QuantityName.Current:
                    return Value2Text(value, effectiveLength, noiseLevel, prefix, "A");
                case QuantityName.Frequency:
                    return Value2Text(value, effectiveLength, noiseLevel, prefix, "Hz");
                case QuantityName.Power:
                    return Value2Text(value, effectiveLength, noiseLevel, prefix, "W");
                case QuantityName.Resistance:
                    return Value2Text(value, effectiveLength, noiseLevel, prefix, "Ω");
                case QuantityName.Temperature:
                    return Value2Text(value, effectiveLength, noiseLevel, prefix, "K");
                case QuantityName.Time:
                    return Value2Text(value, effectiveLength, noiseLevel, prefix, "s");
                case QuantityName.Voltage:
                    return Value2Text(value, effectiveLength, noiseLevel, prefix, "V");
                default:
                    return string.Empty;
            }
        }

        /// <summary>
        /// 将文本转化为物理量
        /// </summary>
        /// <param name="text">代表物理量的文本</param>
        /// <param name="successed">是否转换成功</param>
        /// <returns>转化后的物理量（当successed = true时有效）</returns>
        public static PhysicalVariable Text2Value(string text, out bool successed)
        {
            PhysicalVariable rtn = new PhysicalVariable();
            string num = text;
            string suffix = string.Empty;
            while (text.IndexOf(' ') > 0)
            {
                text = text.Remove(text.IndexOf(' '), 1);
            }
            while ((num.Length > 0) && (!Microsoft.VisualBasic.Information.IsNumeric(num)))
            {
                suffix = num[num.Length - 1] + suffix;
                num = num.Remove(num.Length - 1, 1);
            }
            if (num == string.Empty)
            {
                successed = false;
                rtn.PhysicalVariableType = QuantityName.None;
                rtn.value = 0.0;
                return rtn;
            }

            Symbol symbol = QuantitiesConverter.String2Symbol(suffix);
            if (symbol == Symbol.Hz) suffix = suffix.Remove(suffix.Length - 2);
            else if (symbol != Symbol.None) suffix = suffix.Remove(suffix.Length - 1);
            if (PrefixsConverter.isPrefix(suffix) == false)
            {
                successed = false;
                rtn.PhysicalVariableType = QuantityName.None;
                rtn.value = 0.0;
                return rtn;
            }
            rtn.value = double.Parse(num);
            rtn.value *= Math.Pow(10, PrefixsConverter.prefixString2dec(suffix));
            rtn.PhysicalVariableType = (QuantityName)symbol;
            successed = true;
            return rtn;
        }
    }
        
}

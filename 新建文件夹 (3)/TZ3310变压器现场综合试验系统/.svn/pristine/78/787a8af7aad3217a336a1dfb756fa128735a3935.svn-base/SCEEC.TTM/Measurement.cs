﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCEEC.TTM
{ 
    public static class Measurement
    {
        public static void DoWork(ref TestingWorkerSender sender)
        {
            
        }

        public static bool CancelWork(ref TestingWorkerSender sender)
        {

            return true;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using SCEEC.MI.TZ3310;
using System.ComponentModel;
using SCEEC.Numerics;

namespace SCEEC.TTM
{

    public class DashboardInfo
    {
        public string Name;
        public double Value;
        public string Unit;
        public double Maximum;
    }

    public class TestingWorkerSender
    {
        public MeasurementItemStruct[] MeasurementItems;

        public int ProgressPercent;
        public int CurrentItemIndex;

        public string StatusText;
        public DashboardInfo Dashboard1;
        public DashboardInfo Dashboard2;

        public int RemainingItemsCount
        {
            get
            {
                return MeasurementItems.Length - CurrentItemIndex;
            }
        }

        private List<WrapPanel> list;
        public List<WrapPanel> GetList()
        {
            if (list != null) list.Clear();
            list = new List<WrapPanel>();
            for (int i = 0; i < MeasurementItems.Length; i++)
            {
                WrapPanel wp = new WrapPanel();
                if (i < CurrentItemIndex)
                    wp.Children.Add(new Image() { Margin = new Thickness(5), Source = new BitmapImage(new Uri("Resources/Successed.png", UriKind.Relative)), Height = 18 });
                else if (i == CurrentItemIndex)
                    wp.Children.Add(new Image() { Margin = new Thickness(5), Source = new BitmapImage(new Uri("Resources/Working.png", UriKind.Relative)), Height = 18 });
                else
                    wp.Children.Add(new Image() { Margin = new Thickness(5), Source = new BitmapImage(new Uri("Resources/Pending.png", UriKind.Relative)), Height = 18 });
                wp.Children.Add(new TextBlock() { Margin = new Thickness(5), Text = MeasurementItems[i].Description });
                list.Add(wp);
            }
            return list;
        }
    }

    /// <summary>
    /// WindowTesting.xaml 的交互逻辑
    /// </summary>
    public partial class WindowTesting : Window
    {

        BackgroundWorker TestingWorker;

        JobList currentJob;
        TestingWorkerSender worker;

        public WindowTesting(string transformerSerialNo, string jobName)
        {
            InitializeComponent();
            currentJob = WorkingSets.local.getJob(transformerSerialNo, jobName);
            TestingWorker = new BackgroundWorker();
            TestingWorker.WorkerReportsProgress = true;
            TestingWorker.WorkerSupportsCancellation = true;
            TestingWorker.DoWork += TestingWorker_DoWork;
            TestingWorker.ProgressChanged += TestingWorker_ProgressChanged;
            TestingWorker.RunWorkerCompleted += TestingWorker_RunWorkerCompleted;
            worker = new TestingWorkerSender()
            {
                Dashboard1 = new DashboardInfo()
                {
                    Name = "",
                    Unit = "",
                    Value = 0,
                    Maximum = 10
                },
                Dashboard2 = new DashboardInfo()
                {
                    Name = "",
                    Unit = "",
                    Value = 0,
                    Maximum = 10
                },
                MeasurementItems = Translator.JobList2MeasurementItems(currentJob).ToArray(),
                CurrentItemIndex = -1,
                ProgressPercent = 0
            };
            StatusRefresh(worker);
        }

        private void TestingWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            var worker = e.Argument as TestingWorkerSender;
            while(worker.CurrentItemIndex < worker.MeasurementItems.Length)
            {
                if (TestingWorker.CancellationPending == true)
                {
                    while (!Measurement.CancelWork(ref worker))
                    {
                        TestingWorker.ReportProgress(0, worker);
                        System.Threading.Thread.Sleep(500);
                    }
                    return;
                }
                else
                {
                    Measurement.DoWork(ref worker);
                    worker.CurrentItemIndex++;
                }
                TestingWorker.ReportProgress(worker.ProgressPercent, worker);
                System.Threading.Thread.Sleep(500);
            }
        }

        private void StatusRefresh(TestingWorkerSender status)
        {
            WorkingStatusLabel.Text = status.StatusText;
            DashboardTitle1.Text = status.Dashboard1.Name;
            DashboardUnit1.Text = status.Dashboard1.Unit;
            DashboardValue1.Text = SCEEC.Numerics.NumericsConverter.Value2Text(status.Dashboard1.Value, 3, -6, "", "");
            dashboard1.Value = status.Dashboard1.Value;
            dashboard1.Maximum = status.Dashboard1.Maximum;
            DashboardTitle2.Text = status.Dashboard2.Name;
            DashboardUnit2.Text = status.Dashboard2.Unit;
            DashboardValue2.Text = SCEEC.Numerics.NumericsConverter.Value2Text(status.Dashboard2.Value, 3, -6, "", "");
            dashboard2.Value = status.Dashboard2.Value;
            dashboard2.Maximum = status.Dashboard2.Maximum;

            int itemIndex = TestItemListBox.SelectedIndex;
            TestItemListBox.ItemsSource = status.GetList();
            if (itemIndex < TestItemListBox.Items.Count)
                TestItemListBox.SelectedIndex = itemIndex;
            
            progressBar.Value = status.ProgressPercent;

            RemainingTestNumLabel.Text = status.RemainingItemsCount.ToString();

            GC.Collect();
        }

        private void TestingWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            var status = e.UserState as TestingWorkerSender;
            worker = status;
            StatusRefresh(status);
        }

        private void TestingWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled == true)
            {
                
                return;
            }
        }

        private void Grid_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (this.WindowState != WindowState.Normal)
            {
                this.WindowState = WindowState.Normal;
                this.Top = 0;
            }
            this.DragMove();
        }

        private void MinimumButton_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void MaximumButton_Click(object sender, RoutedEventArgs e)
        {
            if (this.WindowState == WindowState.Maximized)
            {
                this.WindowState = WindowState.Normal;
                maximumButtonImage.Source = new BitmapImage(new Uri("Resources/maximum.png", UriKind.Relative));
            }
            else
            {
                this.WindowState = WindowState.Maximized;
                maximumButtonImage.Source = new BitmapImage(new Uri("Resources/maximum2.png", UriKind.Relative));
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Window_StateChanged(object sender, EventArgs e)
        {
            switch (this.WindowState)
            {
                case WindowState.Minimized:
                    break;
                default:
                    this.Show();
                    this.Activate();
                    break;
            }
        }

        private void StartButton_Click(object sender, EventArgs e)
        {
            if (!TestingWorker.IsBusy) TestingWorker.RunWorkerAsync(worker);
        }

        private void StopButton_Click(object sender, EventArgs e)
        {
            TestingWorker.CancelAsync();
        }
    }
    

}

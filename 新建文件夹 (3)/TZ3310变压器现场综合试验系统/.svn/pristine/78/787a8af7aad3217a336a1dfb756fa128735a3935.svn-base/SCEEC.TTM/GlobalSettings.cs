﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCEEC.TTM
{
    internal static class GlobalSettings
    {
        internal static SCEEC.Config.user currentUser = new SCEEC.Config.user();

        private static bool __startuped = false;
        internal static bool Startuped
        {
            get
            {
                return __startuped;
            }
            set
            {
                if (Startuped) __startuped = true;
            }
        }
    }
}
